#pragma once

void HelloWorld ();
void VariablesAndTypes ();
void Constants ();
void Operators ();
void BasicInputOutput ();