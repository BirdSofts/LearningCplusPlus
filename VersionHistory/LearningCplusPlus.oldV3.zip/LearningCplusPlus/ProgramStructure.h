#pragma once

void ControlStructures ();
void Functions ();
void OverloadsAndTemplates ();
void NameVisibility ();