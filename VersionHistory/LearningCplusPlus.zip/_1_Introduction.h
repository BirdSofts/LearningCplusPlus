﻿// --------------------------------------------------------------------------------
/// <summary>
/// _1_Introduction.h
/// </summary>
/// <created>ʆϒʅ,20.12.2018</created>
/// <changed>ʆϒʅ,14.01.2019</changed>
// --------------------------------------------------------------------------------

#pragma once


#ifndef _1_INTRODUCTION_H
#define _1_INTRODUCTION_H


void _1_1_Introduction ();


#endif // !_1_INTRODUCTION_H