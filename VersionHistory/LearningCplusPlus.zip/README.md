# Introduction 
LearningCplusPlus project originally aimed to serve as a personal private reference for coding in C++ language.
As reference mostly CplusPlus website (http://www.cplusplus.com/ ) has been used, also additionally some other websites which their addresses are in the source code.
The project is just learning materials, which tries very hard to bring learning instruction, the source code itself and the compilation results all together in code environment in easy language which results in experiencing more joy while learning to code.

# Getting Started
If you are a real beginner, just use Visual Studio and try learning the code environment in beginner level first, before starting the C++ language itself.
If you have experience then you probably know what you are doing.

# Build and Test
The project has been built and tested in Visual Studio environment. If you want to do it in other coding environment, then you are going to be on your own.

# Contribute
I appreciate any contribution to the project.
Additionally the project is copyrighted. Most of the code is from the online references and the addition to them can just be used as teaching materials.