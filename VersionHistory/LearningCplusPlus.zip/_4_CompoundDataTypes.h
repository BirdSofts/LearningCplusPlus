﻿// --------------------------------------------------------------------------------
/// <summary>
/// _4_CompoundDataTypes.h
/// </summary>
/// <created>ʆϒʅ,30.05.2018</created>
/// <changed>ʆϒʅ,20.12.2018</changed>
// --------------------------------------------------------------------------------

#pragma once


#ifndef COMPOUNDDATATYPES_H
#define COMPOUNDDATATYPES_H


void Arrays ();
void CharacterSequences ();
void Pointers ();
void DynamicMemory ();
void DataStructures ();
void OtherDataTypes ();


#endif // !COMPOUNDDATATYPES_H