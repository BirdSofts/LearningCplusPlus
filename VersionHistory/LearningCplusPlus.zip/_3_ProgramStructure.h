﻿// --------------------------------------------------------------------------------
/// <summary>
/// _3_ProgramStructures.h
/// </summary>
/// <created>ʆϒʅ,09.05.2018</created>
/// <changed>ʆϒʅ,20.12.2018</changed>
// --------------------------------------------------------------------------------

#pragma once


#ifndef PROGRAMSTRUCTURE_H
#define PROGRAMSTRUCTURE_H


void ControlStructures ();
void Functions ();
void OverloadsAndTemplates ();
void NameVisibility ();


#endif // !PROGRAMSTRUCTURE_H