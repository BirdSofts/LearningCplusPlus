#pragma once

void Arrays ();
void CharacterSequences ();
void Pointers ();
void DynamicMemory ();
void DataStructures ();
void OtherDataTypes ();