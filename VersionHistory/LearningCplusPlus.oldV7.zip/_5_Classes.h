﻿// --------------------------------------------------------------------------------
/// <summary>
/// _5_Classes.h
/// </summary>
/// <created>ʆϒʅ,18.09.2018</created>
/// <changed>ʆϒʅ,16.04.2019</changed>
// --------------------------------------------------------------------------------

#pragma once


#ifndef CLASSES_H
#define CLASSES_H


void ClassesI ();
void ClassesII ();


#endif // !CLASSES_H
